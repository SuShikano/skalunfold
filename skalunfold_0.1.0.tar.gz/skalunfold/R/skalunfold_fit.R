# ---------------------------------------------------------------------------- #
# ##############################################################################
# ---------------------------------------------------------------------------- #
# ##############################################################################
#' Evaluate the fit of posterior to data
#'
#' @param postestimation post-estimation object
#' @param scalo.colors Colors.
#' @param type Determines the type of test. Default is "Residuals". "Q3" and "Criteria" are also possible.
#' @param scalo.names Name labels for the skalometer
#' @param n.iter number of iterations
#' @param cex Size of the labels.
#' @param legend If TRUE legend will be shown.
#' @param random.seed Random seeds.
#' @return List of the results.
# ---------------------------------------------------------------------------- #
# ---------------------------------------------------------------------------- #
# ##############################################################################
# ---------------------------------------------------------------------------- #


skalunfold.fit <- function(postestimation, scalo.colors=NULL,type="residuals",
                            scalo.names=NULL,n.iter=NULL,cex=1,legend=T,
                            random.seed=NULL,alpha=.2,title=NULL){
  if(type=="Rhat"| type=="Residuals"){
  n.iter <- nrow(postestimation$theta.id)
  }
  if(type!="Rhat" & type != "Residuals"){
  # number of iterations to be used
  n.iter <- ifelse(is.null(n.iter),min(nrow(postestimation$theta.id),250),n.iter)

  if(n.iter>nrow(postestimation$theta.id)){
    n.iter = nrow(postestimation$theta.id)
    warning("Desired number of iterations larger than number actually available. Using total nr of iterations instead")
  }
  }

  random.seed <- ifelse(is.null(random.seed),sample(round(1:abs(runif(1,1,10000)),1)),random.seed)
  # select important items
  valence=postestimation$valence
  group=postestimation$group
  gener.last=postestimation$gener.last
  D <- postestimation$dimension # dimension is later used as D
  if(postestimation$distance==1){ W <- 0.5} # distance is regulated with W
  if(postestimation$distance==2){ W <- 1}

  # now select only the desired iterations
  set.seed(random.seed)
  iters <- sort(sample(1:nrow(postestimation$theta.id),n.iter,replace=F))
  skalodata <- postestimation$addinfo
  sigma <- postestimation$sigma[iters]
  theta.id <- array(NA,dim=c(n.iter,nrow(skalodata),D))
  theta.id2 <- array(NA,dim=c(nrow(postestimation$theta.id),nrow(skalodata),D))
  theta.id2[,,1:D] <- postestimation$theta.id
  theta.id[,,1:D] <- theta.id2[which(1:nrow(theta.id2) %in% iters),,1:D]
  beta.id  <- array(NA,dim=c(n.iter,ncol(skalodata),D))
  beta.id2 <- array(NA,dim=c(nrow(postestimation$beta.id),ncol(skalodata),D))
  beta.id2[,,1:D] <- postestimation$beta.id
  beta.id[,,1:D] <- beta.id2[which(1:nrow(beta.id2) %in% iters),,1:D]
  v.st <- postestimation$v.st[iters,]
  if(postestimation$valence!=0 ){
    valence.post    <- postestimation$valence.post[iters,]
  }else{
      valence.post <- matrix(max(skalodata,na.rm=T),ncol=ncol(skalodata),nrow=n.iter)
  }
  if(type=="Criteria"){#--------------------------------------------------------

    valence.nr <- ifelse(postestimation$valence>1,ncol(postestimation$valence.post),
                         ifelse(postestimation$valence==1,1,0))

    parnum <- ncol(v.st) + ncol(v.st)*D + ncol(beta.id)*D + 2 + valence.nr
    nobs <- ncol(v.st)
    dev_mean <- mean(postestimation$deviance)
    dev_upper <- quantile(postestimation$deviance,.95)
    dev_lower <- quantile(postestimation$deviance,.05)
    bic <- mean(postestimation$deviance) + parnum*log(nobs)
    bic_upper <-  quantile(postestimation$deviance,.95) + parnum*log(nobs)
    bic_lower <-  quantile(postestimation$deviance,.05) + parnum*log(nobs)
    aic       <-  mean(postestimation$deviance) + parnum*2
    aic_upper <-  quantile(postestimation$deviance,.95) + parnum*2
    aic_lower <-  quantile(postestimation$deviance,.05) + parnum*2
    crit.mat  <-  cbind(c(dev_mean,dev_lower,dev_upper),
                        c(aic,aic_lower,aic_upper),
                        c(bic,bic_lower,bic_upper))
    colnames(crit.mat) <- c("Deviance","AIC","BIC")
    row.names(crit.mat) <- c("Posterior Mean","5%-Quantile","95%-Quantile")
  return(crit.mat)
    }
  # code to implement some fit analysis and implement PPMC
  if(type=="Residuals"){#---------------------------------------------------------
    ifelse(is.null(title),title <- "Item-Wise Residual Standard Deviation",
           title <- title)
    # compute distances for every possible specification
    pred.values <- array(NA,dim=c(nrow(skalodata),ncol(skalodata),n.iter))
    pb = txtProgressBar(min = 1, max = length(1:n.iter), initial = 1,style=3)
    min.val <- min(skalodata,na.rm=T)
    max.val <- max(skalodata,na.rm=T)
    for(iter in 1:n.iter){
      distances <- 0
      for(d in 1:D){ # loop over dimensions to sum the distances
        distances <- distances + (t(t(theta.id[iter,,d]%*%t(rep(1,ncol(skalodata)))) - beta.id[iter,,d]))^2
      }
      if(valence<3){ #  no valence or generic valence
        pred.values[,,iter] <-   valence.post[iter,] + v.st[iter,]*(distances)^W
      }
      if(valence==3){ # specific valence
        for(i in 1:nrow(skalodata)){ # loop over individuals
          pred.values[,,iter] <-   valence.post[iter,grep(paste0(",",group[i]),
                                                         colnames(valence.post))] +
            v.st[iter,i]*(distances[i,])^W
        }
      }
      if(valence==4){ # mixed valence
        pred.values[,1:gener.last,iter] <-   valence.post[iter,1:gener.last] + v.st[iter,]*(distances[,1:gener.last])^W
        for(i in 1:nrow(skalodata)){ # loop over individuals
          pred.values[i,(gener.last+1):ncol(skalodata),iter] <-
            valence.post[iter,grep(paste0(",",group[i]),
                                  colnames(valence.post))] +
            v.st[iter,i]*(distances[i,(gener.last+1):ncol(skalodata)])^W
        }
      }
      # calculate iteration-specific residuals   sim.values[sim.values>max(skalodata,na.rm=T)] <-max(skalodata,na.rm=T)
      pred.temp <- pred.values[,,iter]
      pred.temp[pred.temp<min.val] <-min.val
      pred.temp[pred.temp>max.val] <-max.val
      pred.temp <- round(pred.temp)
      pred.values[,,iter] <-   pred.temp-skalodata
      # calculate progress
      setTxtProgressBar(pb,iter)
    }
    # average
    resid <-  apply(pred.values,c(1,2),mean,na.rm=T)
    # plot
    ifelse(is.null(scalo.colors),plot.colors <-"black",plot.colors<-scalo.colors)
    plot(1:ncol(skalodata),apply(resid,2,sd,na.rm=T),
         ylim=c(0,max(apply(skalodata,2,sd,na.rm=T))*1.75),
         xlim=c(1,ncol(skalodata)),
         main=title,
         xlab="",
         xaxt="none",
         type="h",lwd=2,
         col=plot.colors,ylab="SD")
    points(1:ncol(skalodata),apply(resid,2,sd,na.rm=T),
           ylim=c(0,max(sigma)*2),pch=19,cex=1.3,
           col=plot.colors)
    abline(h=c(mean(sigma),quantile(sigma,c(.025,.975))),col="black",lty=c(1,2,2))
    ifelse(is.null(scalo.names),scalo.labels <- 1:ncol(skalodata),scalo.labels <- scalo.names)
    axis(1,at=1:ncol(skalodata),labels=scalo.labels,las=2)
    residual.sd <- apply(resid,2,sd,na.rm=T)
    ifelse(is.null(scalo.names),residual.names <- as.character(1:ncol(skalodata)),
           residual.names <- scalo.names)
    names(residual.sd) <- residual.names
    return(list(estimated.sigma=mean(sigma),item.residual.sd=residual.sd))
  }

  #---------------------------------------------------------
  if(type=="Q3"){# PPPMC for Yen's Q3
    library(shape)
    ifelse(is.null(title),title <- "Yen's Q3",title <- title)
    # compute distances for every possible specification
    resid.counter <- array(0,dim=c(ncol(skalodata),ncol(skalodata),n.iter))
    pred.values <- array(NA,dim=c(nrow(skalodata),ncol(skalodata),n.iter))
    pred.values_obs <- array(NA,dim=c(nrow(skalodata),ncol(skalodata),n.iter))
    pb = txtProgressBar(min = 1, max = length(1:n.iter), initial = 1,style=3)
    min.val <- min(skalodata,na.rm=T)
    max.val <- max(skalodata,na.rm=T)
    for(iter in 1:n.iter){
      distances <- 0
      for(d in 1:D){ # loop over dimensions to sum the distances
        distances <- distances + (t(t(theta.id[iter,,d]%*%t(rep(1,ncol(skalodata)))) - beta.id[iter,,d]))^2
      }
      if(valence<3){ #  no valence or generic valence
        pred.values[,,iter] <-   valence.post[iter,] + v.st[iter,]*(distances)^W
      }
      if(valence==3){ # specific valence
        for(i in 1:nrow(skalodata)){ # loop over individuals
          pred.values[,,iter] <-   valence.post[iter,grep(paste0(",",group[i]),
                                                         colnames(valence.post))] +
            v.st[iter,i]*(distances[i,])^W
        }
      }
      if(valence==4){ # mixed valence
        pred.values[,1:gener.last,iter] <-   valence.post[iter,1:gener.last] + v.st[iter,]*(distances[,1:gener.last])^W
        for(i in 1:nrow(skalodata)){ # loop over individuals
          pred.values[i,(gener.last+1):ncol(skalodata),iter] <-
            valence.post[iter,grep(paste0(",",group[i]),
                                  colnames(valence.post))] +
            v.st[iter,i]*(distances[i,(gener.last+1):ncol(skalodata)])^W
        }
      }
      # calculate iteration-specific residuals
      sim.values <- apply(pred.values[,,iter],c(1,2),
                          function(x) rnorm(1,mean=x,sd=sigma[iter]))
      sim.values[sim.values>max.val] <-max.val
      sim.values[sim.values<min.val] <-min.val
      sim.values <- round(sim.values)
      pred.temp <- pred.values[,,iter]
      pred.temp[pred.temp<min.val] <-min.val
      pred.temp[pred.temp>max.val] <-max.val
      pred.values[,,iter] <-   pred.temp
      pred.values_obs[,,iter] <-   pred.values[,,iter]-skalodata
      pred.values[,,iter] <-   pred.values[,,iter]-sim.values
      # calculate residual correlations
      resid.counter[,,iter] <- abs(cor(pred.values[,,iter],use="pairwise.complete.obs")) >
        abs(cor(pred.values_obs[,,iter],use="pairwise.complete.obs"))
      # calculate progress
      setTxtProgressBar(pb,iter)
    }
    # calculate posterior predictive p.value
    resid.counter <- apply(resid.counter,c(1,2),sum,na.rm=T)/n.iter

    # make the pie-chart
    radius.m <- (ncol(skalodata)^(1/2.3))*0.05*cex
    par(mar=c(7,7,4,1))
    plot(0,
         xlim=c(1,ncol(skalodata)-.5),
         ylim=c(1.3,ncol(skalodata)+.5),
         main=title,type="n",
         yaxt="n",xaxt="n",
         ylab="",xlab="")
    for(rows in 1:ncol(skalodata)){
      for(columns in 1:rows){
        if(columns==rows) next
        filledcircle(r1=radius.m, r2=0, from=0, to=2*pi, col=ifelse(resid.counter[columns,rows]>=.05 & resid.counter[columns,rows]<=.95,"Black","Red"), mid=c(columns,rows),
                     val=(cbind(c(0,1),c(0,0))), zlim=c(0,1))
        filledcircle(r1=radius.m, r2=0, from=+.5*pi, to=pi*2*(1-resid.counter[columns,rows])+.5*pi, col="White", mid=c(columns,rows),
                     val=(cbind(c(0,1),c(0,0))), zlim=c(0,1))
        filledcircle(r1=radius.m,r2=radius.m*1.05,from=0, to=2*pi, col=ifelse(resid.counter[columns,rows]>.05 & resid.counter[columns,rows]<.95,"Black","Red"), mid=c(columns,rows),
                     val=(cbind(c(0,1),c(0,0))), zlim=c(0,1))
      }
    }
    if(legend==T){
      rect(ncol(skalodata)-2.5,1.5,ncol(skalodata)-.5,6.5)
      filledcircle(r1=radius.m, r2=0, from=0, to=2*pi, col="Red", mid=c(ncol(skalodata)-2,2),
                   val=(cbind(c(0,1),c(0,0))), zlim=c(0,1))
      filledcircle(r1=radius.m, r2=0, from=0, to=2*pi, col="Black", mid=c(ncol(skalodata)-2,3),
                   val=(cbind(c(0,1),c(0,0))), zlim=c(0,1))
      filledcircle(r1=radius.m, r2=0, from=+.5*pi, to=pi*2*(0.25)+.5*pi, col="White", mid=c(ncol(skalodata)-2,3),
                   val=(cbind(c(0,1),c(0,0))), zlim=c(0,1))
      filledcircle(r1=radius.m,r2=radius.m*1.05,from=0, to=2*pi, col="Black", mid=c(ncol(skalodata)-2,3),
                   val=(cbind(c(0,1),c(0,0))), zlim=c(0,1))
      filledcircle(r1=radius.m, r2=0, from=0, to=2*pi, col="Black", mid=c(ncol(skalodata)-2,4),
                   val=(cbind(c(0,1),c(0,0))), zlim=c(0,1))
      filledcircle(r1=radius.m, r2=0, from=+.5*pi, to=pi*2*(0.5)+.5*pi, col="White", mid=c(ncol(skalodata)-2,4),
                   val=(cbind(c(0,1),c(0,0))), zlim=c(0,1))
      filledcircle(r1=radius.m,r2=radius.m*1.05,from=0, to=2*pi, col="Black", mid=c(ncol(skalodata)-2,4),
                   val=(cbind(c(0,1),c(0,0))), zlim=c(0,1))
      filledcircle(r1=radius.m, r2=0, from=0, to=2*pi, col="Black", mid=c(ncol(skalodata)-2,5),
                   val=(cbind(c(0,1),c(0,0))), zlim=c(0,1))
      filledcircle(r1=radius.m, r2=0, from=+.5*pi, to=pi*2*(0.75)+.5*pi, col="White", mid=c(ncol(skalodata)-2,5),
                   val=(cbind(c(0,1),c(0,0))), zlim=c(0,1))
      filledcircle(r1=radius.m,r2=radius.m*1.05,from=0, to=2*pi, col="Black", mid=c(ncol(skalodata)-2,5),
                   val=(cbind(c(0,1),c(0,0))), zlim=c(0,1))
      filledcircle(r1=radius.m,r2=radius.m*1.05,from=0, to=2*pi, col="Red", mid=c(ncol(skalodata)-2,6),
                   val=(cbind(c(0,1),c(0,0))), zlim=c(0,1))
      text(ncol(skalodata)-1,2,1)
      text(ncol(skalodata)-1,3,.75)
      text(ncol(skalodata)-1,4,.5)
      text(ncol(skalodata)-1,5,.25)
      text(ncol(skalodata)-1,6,0)
    }
    ifelse(is.null(scalo.names),scalo.labels <- 1:ncol(skalodata),scalo.labels <- scalo.names)

    axis(1,1:ncol(skalodata),labels=scalo.labels,las=2)
    axis(2,2:ncol(skalodata),labels=scalo.labels[2:ncol(skalodata)],las=2)
    colnames(resid.counter) <-scalo.labels
    row.names(resid.counter) <-scalo.labels
    return(list(nr.probl.pairs=sum(lower.tri(diag(ncol(skalodata)))*(resid.counter>=.95|resid.counter<=.05)),
                p.values= resid.counter))
  }

  if(type=="Rhat"){
  # function to calculate r.hat
rhat.calc <- function(x,nchains=NULL,alpha=.2){
  x <- as.vector(x)
  separator <- length(x)/nchains
  varlist <- vector(mode="numeric",length=nchains)
  for(i in 1:length(varlist)){
    temp <- sort(x[(separator*(i-1)+1):(separator*i)])
    temp <- temp[round(separator*(alpha/2)):round(separator-separator*(alpha/2))]
    varlist[i] <- max(temp)- min(temp)
  }
  temp <- sort(x)
  temp <- temp[round(length(x)*(alpha/2)):round(length(x)-length(x)*(alpha/2))]
  return(round((max(temp)-min(temp))/mean(varlist),4))
}

  if(postestimation$n.chains==1){
    stop("Number of chains for the computation of Rhat needs to be 2 or greater")}
    # function to calculate rhat

    # apply to different parameters
    rhat.list <- vector(mode="list",length=5)
    rhat.list[[1]] <- apply(beta.id,2:(D+1),rhat.calc,
                                  nchains=postestimation$n.chains,
                                  alpha=alpha)
    if(D>1){ rhat.list[[1]] <- apply(rhat.list[[1]],1,mean)}
    if(postestimation$valence>0){
    rhat.list[[2]] <- apply(apply(valence.post,2,rhat.calc,
                                  nchains=postestimation$n.chains,
                                  alpha=alpha),
                            1,mean)}
    rhat.list[[3]] <- apply(theta.id,2:(D+1),rhat.calc,
                                  nchains=postestimation$n.chains,
                                  alpha=alpha)
     if(D>1){ rhat.list[[3]] <- apply(rhat.list[[3]],1,mean)}
    rhat.list[[3]] <- c(mean(rhat.list[[3]]),
                        quantile(rhat.list[[3]],c(.025,.975)))
    rhat.list[[4]] <-  apply(v.st,2,rhat.calc,
                             nchains=postestimation$n.chains,
                             alpha=alpha)
    rhat.list[[4]] <- c(mean(rhat.list[[4]]),
                        quantile(rhat.list[[4]],c(.025,.975)))
    rhat.list[[5]] <- rhat.calc(sigma,
                                nchains=postestimation$n.chains,
                                alpha=alpha)
names(rhat.list) <- c("Ideological Positions Beta",
                      "Valence Alpha",
                      "Voter Position Theta",
                      "Ideology Weight V",
                      "Random Error Sigma")
return(rhat.list)
  }
}







