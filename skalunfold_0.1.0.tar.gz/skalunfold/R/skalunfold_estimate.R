# ---------------------------------------------------------------------------- #
# SKALOUNFOLD (Susumu Shikano/Konstantin Käppner/John Körtner)
#   via JAGS
#   Parallelized estimation
# ---------------------------------------------------------------------------- #
# ##############################################################################
#
#
#
# ##############################################################################
#' Run MCMC to obtain posteriors of spatial positions and valence
#'
#' @param valence Valence specification. 0 estimates no valence, but the constant is set to
#'        the maximal value of the raw score. 1 estimates one single valence value for all actors.
#'        2 estimates a valence for each actor.
#'        3 estimates groups specific valence for each actor.
#'        4 is mixture of 2 and 3.
#' @param distance Distance metric. 1 for lienar distance. 2 for quadratic distance.
#' @param dimension Number of dimension. Minimum is 1 and maximum is 3.
#' @param group Variable which defines groups of respondents.
#' @param weight Variable which defines structure of ideology weight. 1 (default) is for weighted unfolding model.
#'	      2 gives weights based on observed groups (needs variable group to be specified).
#'	      3 produces a single weight for all respondents.
#' @param skalodata Thermometer score data
#' @param n.chains Number of chains
#' @param gener.last Only for the mixed valence (valence=4). This specifies the number of generic valence.
#' @param n.clusters Number of clusters
#' @param create.files Specifies whether to create external files of posterior.
#' @param n.iter Number of iterations
#' @param n.burnin Length of burnin
#' @param gamma.shape A positive value, which specifies the shape parameter of the gamma prior for the weighting parameter. Default is 2.
#' @return A skalunfold object. This is a list of estimation results. They are not identified. To identify, use skalunfold.postestimate()
#' @examples
#' library(skalunfold)
#' data("student.skalo.ws1617")
#' skalometers <- student.skalo.ws1617[,grep("w1",colnames(student.skalo.ws1617))]
#' num.na <- apply(is.na(skalometers),1,sum)
#' skalometers <- skalometers[num.na<7,]
#'
#' posterior <- skalunfold.estimate(skalodata=skalometers ,valence=2,distance=1,dimension=1,n.chains=3,
#'                                   n.iter=1000,n.burnin=2000)
#' identified.posterior <- skalunfold.postestimate(posterior)
#' skalunfold.graph(identified.posterior,type="ideology")
#'
#' posterior <- skalunfold.estimate(skalodata=skalometers ,valence=2,distance=1,dimension=2,n.chains=3,
#'                                   n.iter=1000,n.burnin=2000)
#' identified.posterior <- skalunfold.postestimate(posterior)
#' skalunfold.graph(identified.posterior,type="valence")
#'
# ---------------------------------------------------------------------------- #
skalunfold.estimate <-
  function(skalodata,
           valence=2,
           distance=1,
           dimension=1,
           group=NULL,
           weight=1,
           n.chains=3,
           gener.last=NULL,
           n.clusters=n.chains,
           create.files=F,
           n.iter=500,
           n.burnin=300,
           gamma.shape=2
  ){
    library(plyr)
    print(paste0("Running Skalunfold with ",n.chains, " chains on ",n.clusters,
                 " clusters,", n.burnin," burn-in iterations and ", n.iter,
                 " iterations. Please wait."))

    if(!(valence %in% 0:4)){ # check if valence is rightly specified
      stop("valence has to be 0, 1, 2, 3 or 4.")
    }

    if(distance!=1 & distance!=2){ # check if distance is rightly specified
      stop("distance has to be 1 or 2.")
    }
    if(valence>2){
      if(valence>2 & length(group)!=nrow(skalodata)){
        stop("group vector must be of length equal to the number of respondents")
      }
    }
    if(valence==4 & (is.null(gener.last))){
      stop("For mixed valence (option valence=4), you need to specify an integer denoting last of the data columns
           for which the valence is generic and does not vary by group.")
    }
    if(!is.null(group)){
      # mapping group variable to numeric variable
      group.l <- length(unique(group))
      group <-  mapvalues(group,sort(unique(group),na.last=T),1:length(unique(group)))
    }

    library(doParallel)
    # names: the specification appears in the model names.
    if(valence==0|valence==1){ val.name <- c("constant")}
    if(valence==2){ val.name <- c("generic")}
    if(valence==3){ val.name <- c("specific")}
    if(valence==4){ val.name <- c("mix")}
    if(distance==2){ dist.name <- c("quad")}
    if(distance==1){ dist.name <- c("abs")}
    dim.name <- paste0(dimension,"dim")
    # parameter:
    D <- dimension # dimension is later used as D
    if(distance==2){ W <- 1} # distance is regulated with W
    if(distance==1){ W <- 0.5}
    # Standard Deviation of Data
    sd.bound <- max(apply(skalodata,2,sd,na.rm=T))*3

    # ------------------------------------------------------------------------
    # ------------------------------------------------------------------------
    # models
    # ------------------------------------------------------------------------
    # ------------------------------------------------------------------------
    if(valence==0 ){ # 1: No valence    ------------------------------------- #
      model <- "model{
        for (i in 1:N){
          for (j in 1:J){
            Y[i,j] ~ dnorm(mu[i,j],sigma2)
            mu[i,j] <- alpha[j] + pow(difference[i,j],W)*v[i]

            difference[i,j] <- sum(difference3[i,j,1:D])
            for(d in 1:D){
            difference3[i,j,d] <- pow(difference2[i,j,d],2)
            difference2[i,j,d] <- theta[i,d] - beta[j,d]
          }
        }
      }

      # priors:
      sigma2 <- pow(sigma,-2)
      sigma ~ dunif(0,sd.bound)
      for (j in 1:J){
      alpha[j] <- B
      }
      for (j in 1:J){
      for (d in 1:D){ # dimensions
      beta[j,d] ~ dnorm(0,1)
      }
      }
      for (i in 1:N){
      for (d in 1:D){ # dimensions
      theta[i,d] ~ dnorm(0,0.1)
      }
      }
      for (i in 1:N){
      v[i] <- v2[v.index[i]]*-1
      }
      for(v.index.counter in 1:v.index.max){
	        v2[v.index.counter] ~dgamma(r1,r2)
      }
      r1 <- gamma.shape
      r2 ~dgamma(0.0001,0.0001)
    }"
    #write(model, paste0("skalovalenz",val.name,dist.name,dim.name,".bug"))
  }

    # models
    if(valence==1 ){ # 1: Constant valence    ------------------------------------- #
      model <- "model{
        for (i in 1:N){
          for (j in 1:J){
            Y[i,j] ~ dnorm(mu[i,j],sigma2)
            mu[i,j] <- alpha[j] + pow(difference[i,j],W)*v[i]

            difference[i,j] <- sum(difference3[i,j,1:D])
            for(d in 1:D){
            difference3[i,j,d] <- pow(difference2[i,j,d],2)
            difference2[i,j,d] <- theta[i,d] - beta[j,d]
            }
          }
        }

      # priors:
      sigma2 <- pow(sigma,-2)
      sigma ~ dunif(0,sd.bound)
      for (j in 1:J){
        alpha[j] <- alpha.0
      }
      alpha.0 ~ dnorm(0,.01)
      for (j in 1:J){
        for (d in 1:D){ # dimensions
          beta[j,d] ~ dnorm(0,1)
        }
      }
      for (i in 1:N){
        for (d in 1:D){ # dimensions
          theta[i,d] ~ dnorm(0,0.1)
        }
      }
      for (i in 1:N){
         v[i] <- v2[v.index[i]]*-1
      }
      for(v.index.counter in 1:v.index.max){
         v2[v.index.counter] ~dgamma(r1,r2)
      }
      r1 <- gamma.shape
      r2 ~dgamma(0.0001,0.0001)
    }"
    #write(model, paste0("skalovalenz",val.name,dist.name,dim.name,".bug"))
    }

    if(valence==2){ # Generic valence    ------------------------------------- #
      model <- "model{
        for (i in 1:N){
          for (j in 1:J){
            Y[i,j] ~ dnorm(mu[i,j],sigma2)
            mu[i,j] <- alpha[j] + pow(difference[i,j],W)*v[i]
            difference[i,j] <- sum(difference3[i,j,1:D])
            for(d in 1:D){
              difference3[i,j,d] <- pow(difference2[i,j,d],2)
              difference2[i,j,d] <- theta[i,d] - beta[j,d]
            }
          }
        }

      # priors:
      sigma2 <- pow(sigma,-2)
      sigma ~ dunif(0,sd.bound)
      for (j in 1:J){
        alpha[j] ~ dnorm(C,.01)  ## We should not truncate here!
      }
      for (j in 1:J){
        for (d in 1:D){ # dimensions
          beta[j,d] ~ dnorm(0,1)
        }
      }
      for (i in 1:N){
        for (d in 1:D){ # dimensions
          theta[i,d] ~ dnorm(0,0.1)
        }
      }
      for (i in 1:N){
          v[i] <- v2[v.index[i]]*-1
      }
      for(v.index.counter in 1:v.index.max){
          v2[v.index.counter] ~dgamma(r1,r2)
      }
      r1 <- gamma.shape
      r2 ~dgamma(0.0001,0.0001)
    }"
    #write(model, paste0("skalovalenz",val.name,dist.name,dim.name,".bug"))
      }

    if(valence==3){ # Group specific ----------------------------------------- #
      model <- "model{
        for (i in 1:N){ # respondents
          for (j in 1:J){ # candidates
            Y[i,j] ~ dnorm(mu[i,j],sigma2)
            mu[i,j] <- alpha[j,G[i]] + pow(difference[i,j],W)*v[i] # group
            # specific valence
            difference[i,j] <- sum(difference3[i,j,1:D])
            for(d in 1:D){
              difference3[i,j,d] <- pow(difference2[i,j,d],2)
              difference2[i,j,d] <- theta[i,d] - beta[j,d]
            }
          }
        }

      # priors:
      sigma2 <- pow(sigma,-2)
      sigma ~ dunif(0,sd.bound)
      for (j in 1:J){
        for(k in 1:K){
          alpha[j,k] ~ dnorm(C,.01)
        }
      }
      for (j in 1:J){
        for(d in 1:D){
          beta[j,d] ~ dnorm(0,1)
        }
      }
      for (i in 1:N){
        for (d in 1:D){ # dimensions
          theta[i,d] ~ dnorm(0,0.1)
        }
      }
      for (i in 1:N){
          v[i] <- v2[v.index[i]]*-1
      }
      for(v.index.counter in 1:v.index.max){
    	    v2[v.index.counter] ~dgamma(r1,r2)
      }
      r1 <- gamma.shape
      r2 ~dgamma(0.0001,0.0001)
    }"

      #write(model, paste0("skalovalenz",val.name,dist.name,dim.name,".bug"))
      }

    if(valence==4){ # mixed  ---------------------------------------------------- #
      model <- "model{
        for (i in 1:N){ # loop for individual respondents
          for (j in 1:J){ # loop for candidate
            Y[i,j] ~ dnorm(mu[i,j],sigma2)
            mu[i,j] <- alpha1[j] + pow(difference[i,j],W)*v[i]
            difference[i,j] <- sum(difference3[i,j,1:D])
            for(d in 1:D){
              difference3[i,j,d] <- pow(difference2[i,j,d],2)
              difference2[i,j,d] <- theta[i,d] - beta[j,d]
            }
          }
          for (l in (J+1):L){
            Y[i,l] ~ dnorm(mu[i,l],sigma2)
            mu[i,l] <- alpha2[(l-J),G[i]] + pow(difference[i,l],W)*v[i]
            difference[i,l] <- sum(difference3[i,l,1:D])
            for(d in 1:D){
              difference3[i,l,d] <- pow(difference2[i,l,d],2)
              difference2[i,l,d] <- theta[i,d] - beta[l,d]
            }
          }

        }

      # priors:
      sigma2 <- pow(sigma,-2)
      sigma ~ dunif(0,sd.bound)
      for (j in 1:J){
        alpha1[j]  ~ dnorm(C,.01)
      }
      for (l in (J+1):L){
        for(k in 1:K){
          alpha2[(l-J),k] ~ dnorm(C,.01)
        }
      }
      for (l in 1:L){
        for(d in 1:D){
          beta[l,d] ~ dnorm(0,1)
        }
      }
      for (i in 1:N){
        for (d in 1:D){ # dimensions
          theta[i,d] ~ dnorm(0,0.1)
        }
      }
      for (i in 1:N){
        v[i] <- v2[v.index[i]]*-1
      }
      for(v.index.counter in 1:v.index.max){
	      v2[v.index.counter] ~dgamma(r1,r2)
      }
      r1 <- gamma.shape
      r2 ~dgamma(0.0001,0.0001)
    }"
    #write(model, paste0("skalovalenz",val.name,dist.name,dim.name,".bug"))
      }
    # -------------------------------------------------------------------------- #
    Y <- skalodata
    Y <- as.matrix(Y)
    A <- min(Y,na.rm=T) # lower scale end
    B <- max(Y,na.rm=T) # upper scale end
    C <- (A+B)/2
    N <- dim(Y)[1]
    J <- dim(Y)[2]
    print("Data, initial values and model files prepared.
          Now starting parallelized estimation.")
    #----------------------------------------------------------------------------#
    library(runjags)
    library(coda)
    # ----------------------------------------------------------------------------
    # ----------------------------------------------------------------------------
    # parallelized via runjags

      if(weight==1){
        v.index=1:N
        v.index.max <- max(v.index)
        v.lower=.1
        v.upper=4
      }
      if(weight==2){
        if(is.null(group)){stop("No group vector specified. Model with group-specific weights needs group vector!")}
        v.index <-as.vector(group)
        v.index.max <- max(v.index)
        v.lower=.1
        v.upper=4
      }
      if(weight==3){
        v.index <- as.vector(rep(1,N))
        v.index.max <- max(v.index)
        v.lower=.1
        v.upper=4
      }
      if(valence==3 | valence==4){
        K <- group.l
        G <- as.vector(group)
      }
      if(valence==4){
        J <- as.integer(gener.last)
        L <- dim(Y)[2]
      }
      if(valence==0){
        jags.data <- list(Y=Y, N=N,J=J,B=B,D=D,W=W,sd.bound=sd.bound,gamma.shape=gamma.shape,
                          v.index=v.index,
                          v.index.max=v.index.max)
        jags.inits <- function(){list(theta=matrix(runif(N*D,-.1,.1),ncol=D,nrow=N),
                                      beta=matrix(runif(J*D,-.1,.1),ncol=D,nrow=J),sigma=sd.bound*0.99,
                                      v2=runif(v.index.max,v.lower,v.upper))}
      }
      if(valence==1){
        jags.data <- list(Y=Y, N=N,J=J,D=D,W=W,sd.bound=sd.bound,gamma.shape=gamma.shape,
                          v.index=v.index,
                          v.index.max=v.index.max)
        jags.inits <- function(){list(theta=matrix(runif(N*D,-.1,.1),ncol=D,nrow=N),
                                      beta=matrix(runif(J*D,-.1,.1),ncol=D,nrow=J),sigma=sd.bound*0.99,
                                      v2=runif(v.index.max,v.lower,v.upper),alpha=rep(runif(1,A,B),J))}
      }
      if(valence==2){
        jags.data <- list(Y=Y, N=N,J=J,D=D,W=W,C=C,sd.bound=sd.bound,gamma.shape=gamma.shape,
                          v.index=v.index,
                          v.index.max=v.index.max)
        jags.inits <- function(){list(theta=matrix(runif(N*D,-.1,.1),ncol=D,nrow=N),
                                      beta=matrix(runif(J*D,-.1,.1),ncol=D,nrow=J),sigma=sd.bound*0.99,
                                      alpha=runif(J,A,B),v2=runif(v.index.max,v.lower,v.upper))}
      }
      if(valence==3){

        jags.data <- list(Y=Y, N=N,J=J,D=D,W=W,C=C,G=G,K=K,sd.bound=sd.bound,gamma.shape=gamma.shape,
                          v.index=v.index,
                          v.index.max=v.index.max)
        jags.inits <- function(){list(theta=matrix(runif(N*D,-.1,.1),ncol=D,nrow=N),
                                      beta=matrix(runif(J*D,-.1,.1),ncol=D,nrow=J),sigma=sd.bound*0.99,
                                      alpha=matrix(runif(J*K,A,B),ncol=K,nrow=J),
                                      v2=runif(v.index.max,v.lower,v.upper))}
      }
      if(valence==4){
        jags.data <- list(Y=Y, N=N,J=J,D=D,W=W,C=C,G=G,K=K,L=L,sd.bound=sd.bound,gamma.shape=gamma.shape,
                          v.index=v.index,
                          v.index.max=v.index.max)
        jags.inits <- function(){list(theta=matrix(runif(N*D,-.1,.1),ncol=D,nrow=N),
                                      beta=matrix(runif(L*D,-.1,.1),ncol=D,nrow=L),
                                      sigma=sd.bound*0.99,alpha2=matrix(runif((L-J)*K,A,B),ncol=K,nrow=(L-J)),
                                      alpha1=runif(J,A,B),v2=runif(v.index.max,v.lower,v.upper))}
      }

      monitorvec <-   c("theta","beta","alpha1","alpha2","v","sigma","deviance")
      if(valence %in% c(2,3)){
        monitorvec <-  c("theta","alpha","beta","v","sigma","deviance")
      }
      if(valence ==0){monitorvec <-  c("theta","beta","v","sigma","deviance")}
      if(valence ==1){monitorvec <-  c("theta","alpha","beta","v","sigma","deviance")}

      jags.samples <- run.jags(model=model,
                               data=jags.data,
                               n.chains=n.chains,
                               inits=jags.inits(),
                               burnin=0,
                               adapt=n.burnin,
                               sample=n.iter,
                               monitor=monitorvec,
                               method="rjparallel",
                               modules=c("dic","glm"))
      jags.samples <- as.matrix(do.call("rbind",jags.samples$mcmc))

    deviance <- jags.samples[,which(colnames(jags.samples)=="deviance")]
    posterior <- jags.samples[,-which(colnames(jags.samples)=="deviance")]

    return(list(addinfo=Y,
                posterior=posterior, deviance=deviance,
                n.chains=n.chains,n.iter=n.iter,gener.last=gener.last,
                valence=valence, distance=distance, dimension=dimension, group=group))
    }

