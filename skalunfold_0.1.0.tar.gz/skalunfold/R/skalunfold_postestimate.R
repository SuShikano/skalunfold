# ---------------------------------------------------------------------------- #
# ##############################################################################
# ##############################################################################
#' This function identifies the estimation results from skalunfold.estimate(...).
#'
#' @param estimation Object produced by skalunfold.estimate(...)
#' @param targetvec Target vector for the first dimension of actors' positions. Default is NULL.
#' @param n.sample.iter Number of samples to find the target iteration. Default is 10.
#' @return An identified skalunfold object This is a list of identified estimation results.
# ---------------------------------------------------------------------------- #
# SKALOVALENZ POSTESTIMATE --------------------------------------------------- #
skalunfold.postestimate <- function(estimation, targetvec=NULL, n.sample.iter=10) {

  if(exists("estimation")==FALSE){
    stop("Please run skalunfold.estimate before using the postestimation.")
  }
  if(estimation$dimension>3){
    stop("Postestimation is not available for more than 3 dimensions.")
  }

  if(estimation$dimension==1){ #---------------------------------------------- #
    theta <- estimation$posterior[,grep("theta",colnames(estimation$posterior))]
    beta <-  estimation$posterior[,grep("beta",colnames(estimation$posterior))]
    if(estimation$valence!=0){
      alpha <- estimation$posterior[,grep("alpha",colnames(estimation$posterior))]
    }
    v <-  estimation$posterior[,grep("v",colnames(estimation$posterior))]
    sigma <-estimation$posterior[,grep("sigma",colnames(estimation$posterior))]
    means <- apply(beta,1,mean)   # scale identification
    sds <- sqrt(apply(beta,1,var)*((ncol(beta)-1)/ncol(beta)))
    v.st <- v * sds^ifelse(estimation$distance==1,1,2)
    beta.st <- (beta-means)/sds
    theta.st <- (theta-means)/sds
    if(is.null(targetvec)){
      direction <- ifelse(beta.st[,1]<0,-1,1)
    }
    if(!is.null(targetvec)){
      firstnonmiss <- min(which(!is.na(targetvec)))
      direction1 <- ifelse(targetvec[firstnonmiss]-mean(targetvec,na.rm=T)>0,1,0)
      direction=ifelse((beta.st[,firstnonmiss]>0)*direction1==1,1,
                       ifelse((beta.st[,firstnonmiss]<0)*(direction1)==1,-1,
                              ifelse((beta.st[,firstnonmiss]>0)*(direction1==0)==1,-1,1)))
    }
    beta.id <- beta.st/direction
    theta.id <- theta.st/direction
    if(estimation$valence==0){alpha <- NA}
    if(estimation$valence==1){
      alpha <- estimation$posterior[,grep("alpha",colnames(estimation$posterior))]
    }

    return(list(addinfo=estimation$addinfo,deviance=estimation$deviance,sigma=sigma,
                valence=estimation$valence, distance=estimation$distance, dimension=estimation$dimension,
                group=estimation$group,gener.last=estimation$gener.last,
                valence.post=alpha,theta.id=theta.id,v.st=v.st,beta.id=beta.id))
  }
  if(estimation$dimension==2){ #---------------------------------------------- #

    library(shapes)
    library(MASS)

    # separate parameters:
    theta <- estimation$posterior[,grep("theta",colnames(estimation$posterior))]
    theta <- array(c(theta[,grep(",1",colnames(theta))],theta[,grep(",2",colnames(theta))]),dim=c(nrow(theta),0.5*dim(theta)[2],2))
    beta <- estimation$posterior[,grep("beta",colnames(estimation$posterior))]
    beta <- array(c(beta[,grep(",1",colnames(beta))],beta[,grep(",2",colnames(beta))]),dim=c(nrow(beta),0.5*dim(beta)[2],2))
    if(estimation$valence!=0){
      alpha <- estimation$posterior[,grep("alpha",colnames(estimation$posterior))]
    }
    v <- estimation$posterior[,grep("v",colnames(estimation$posterior))]
    sigma <-estimation$posterior[,grep("sigma",colnames(estimation$posterior))]
    #means <- apply(theta,c(1,3),mean) # scale identification
    means <- apply(beta,c(1,3),mean) # scale identification
    #sds <- apply(theta,c(1,3),var)*(nrow(estimation$addinfo)-1)/nrow(estimation$addinfo)
    sds <- apply(beta,c(1,3),var)*(dim(beta)[2]-1)/dim(beta)[2]
    sds <- apply(sds,1,mean)
    sds <- sqrt(sds)
    theta.st <- array(c((theta[,,1]-means[,1])/sds, (theta[,,2]-means[,2])/sds),dim=c(dim(theta)))
    beta.st <- array(c((beta[,,1]-means[,1])/sds, (beta[,,2]-means[,2])/sds),dim=c(dim(beta)))
    v.st <- v * sds^ifelse(estimation$distance==1,1,2)

    # procrustes rotation and left-right target rotation:
    sampled.targets <- sample(1:dim(theta.st)[1], n.sample.iter, replace = FALSE)
    start <- date()
    oss.all <- NULL
    for (i.target in sampled.targets){
      target <- beta.st[i.target,,]
      print(paste("Now checking ",which(sampled.targets==i.target),". iteration",sep=""))
      for (i in 1:dim(theta.st)[1]){
        this.config <- beta.st[i,,]
        oss.all <- rbind(oss.all,c(i.target,procOPA(target, this.config, scale = F, reflect = TRUE)$OSS))
      }
    }
    end <- date()
    oss.med <- tapply(oss.all[,2],as.factor(oss.all[,1]),median)
    no.target <- as.numeric(names(which(oss.med == min(oss.med))))
    target <- beta.st[no.target,,]

    if(length(targetvec)>0) { # rotate first dimension to perceived left-right
      # locations of political actors
      if(length(targetvec)!=ncol(beta.st)){
        stop("targetvector is of wrong length")
      }

      gamma.1 <- coef(lm(targetvec ~ 1 + beta.st[no.target,,1]  +  beta.st[no.target,,2]))[2]
      gamma.2 <- coef(lm(targetvec ~ 1 + beta.st[no.target,,1]  +  beta.st[no.target,,2]))[3] *(-1)
      cos.delta  <- gamma.1/sqrt(gamma.1^2+gamma.2^2)
      sin.delta  <- gamma.2/sqrt(gamma.1^2+gamma.2^2)
      target.new  <- cbind(beta.st[no.target,,1]*cos.delta-beta.st[no.target,,2]*sin.delta,
                           beta.st[no.target,,1]*sin.delta+beta.st[no.target,,2]*cos.delta)

      target_list <- vector(mode="list")
      target_list[[1]] <- no.target
      target_list[[2]] <- target
      target_list[[3]] <- as.numeric(estimation$targetvec)
    }
    if(length(targetvec)==0){
      target_list <- vector(mode="list")
      target.new <- beta.st[no.target,,]
    }

    for (i in 1:dim(theta.st)[1]){ # rotation
      this.config <- beta.st[i,,]
      beta.st[i,,] <- procOPA(target.new, this.config, scale = F, reflect = TRUE)$Bhat
      rot.mat <-   procOPA(target.new, this.config, scale = F, reflect = TRUE)$R
      this.theta <- theta.st[i,,]
      theta.st[i,,] <- this.theta%*%rot.mat
    }
    if(estimation$valence==0){
      alpha <- NA
    }
    if(estimation$valence==1){
      alpha <- estimation$posterior[,grep("alpha",colnames(estimation$posterior))]
    }
    return(list(addinfo=estimation$addinfo,deviance=estimation$deviance,targetvec=targetvec,
                valence=estimation$valence, distance=estimation$distance, dimension=estimation$dimension,
                group=estimation$group,gener.last=estimation$gener.last,sigma=sigma,
                valence.post=alpha,theta.id=theta.st,v.st=v.st,beta.id=beta.st,targetlist=target_list))
  }

  if(estimation$dimension==3){ # --------------------------------------------- #

    require(shapes)
    require(MASS)
    sigma <- estimation$posterior[,"sigma"]
    theta <- estimation$posterior[,grep("theta",colnames(estimation$posterior))]
    theta <- array(c(theta[,grep(",1",colnames(theta))],
                     theta[,grep(",2",colnames(theta))],
                     theta[,grep(",3",colnames(theta))]),dim=c(nrow(theta[,seq(1,ncol(theta)-2,3)]),ncol(theta[,seq(2,ncol(theta)-1,3)]),3))
    beta <- estimation$posterior[,grep("beta",colnames(estimation$posterior))]
    beta <- array(c(beta[,grep(",1",colnames(beta))],
                    beta[,grep(",2",colnames(beta))],
                    beta[,grep(",3",colnames(beta))]),dim=c(nrow(beta[,seq(1,ncol(beta)-2,3)]),ncol(beta[,seq(2,ncol(beta)-1,3)]),3))
    if(estimation$valence!=0){
      alpha <- estimation$posterior[,grep("alpha",colnames(estimation$posterior))]
    }
    bias.var <- function(theta){
      sum((theta - mean(theta))^2)/(length(theta))
    }

    means <- apply(beta,c(1,3),mean)
    sds <- apply(beta,c(1,3),bias.var)
    sds <- apply(sds,1,mean)
    sds <- sqrt(sds)

    # scaling
    theta.st <- array(c((theta[,,1]-means[,1])/sds, (theta[,,2]-means[,2])/sds, (theta[,,3]-means[,3])/sds),dim=c(dim(theta)))
    beta.st <- array(c((beta[,,1]-means[,1])/sds, (beta[,,2]-means[,2])/sds, (beta[,,3]-means[,3])/sds),dim=c(dim(beta)))


    v <-  estimation$posterior[,grep("v",colnames(estimation$posterior))]
    v.st <- v * sds^ifelse(estimation$distance==1,1,2)

    # procrustes rotation
    sampled.targets <- sample(1:dim(beta.st)[1], n.sample.iter, replace = FALSE)
    start <- date()
    oss.all <- NULL
    for (i.target in sampled.targets){

      target <- beta.st[i.target,,]
      for (i in 1:dim(beta.st)[1]){
        print(paste(which(sampled.targets==i.target)," and ",i,sep=""))
        this.config <- beta.st[i,,]
        oss.all <- rbind(oss.all,c(i.target,procOPA(target, this.config, scale = F, reflect = TRUE)$OSS))
      }
    }
    end <- date()

    oss.med <- tapply(oss.all[,2],as.factor(oss.all[,1]),median)
    no.target <- as.numeric(names(which(oss.med == min(oss.med))))
    target <- beta.st[no.target,,]

    # left-right data for target rotation:
    if(length(targetvec)>0) {

      if(length(targetvec)!=ncol(beta.st)){
        stop("targetvector is of wrong length")
      }

      gamma.1 <- coef(lm(targetvec ~ 1 + beta.st[no.target,,1]  +  beta.st[no.target,,2]+  beta.st[no.target,,3]))[2]
      gamma.2 <- coef(lm(targetvec ~ 1 + beta.st[no.target,,1]  +  beta.st[no.target,,2]+  beta.st[no.target,,3]))[3]
      gamma.3 <- coef(lm(targetvec ~ 1 + beta.st[no.target,,1]  +  beta.st[no.target,,2]+  beta.st[no.target,,3]))[4]

      sin.delta1 <- -gamma.2/sqrt(gamma.1^2+gamma.2^2+gamma.3^2)
      cos.delta1 <- sqrt(1-(gamma.2^2/(gamma.1^2+gamma.2^2+gamma.3^2)))
      sin.delta2 <- -(gamma.3/sqrt(gamma.1^2+gamma.3^2))
      cos.delta2 <- gamma.1/sqrt(gamma.1^2+gamma.3^2)

      rot.mat <- rbind(c(cos.delta1*cos.delta2, -sin.delta1, -cos.delta1*sin.delta2),
                       c(sin.delta1*cos.delta2,  cos.delta1, -sin.delta1*sin.delta2),
                       c(sin.delta2,                      0,  cos.delta2))

      target.new <- t(rot.mat %*% t(beta.st[no.target,,]))

      target_list <- vector(mode="list")
      target_list[[1]] <- no.target
      target_list[[2]] <- target
      target_list[[3]] <- as.numeric(estimation$targetvec)
    }

    if(length(targetvec)==0){
      target_list <- vector(mode="list")
      target.new <- beta.st[no.target,,]
    }

    for (i in 1:dim(theta.st)[1]){
      this.config <- beta.st[i,,]
      beta.st[i,,] <- procOPA(target.new, this.config, scale = F, reflect = TRUE)$Bhat
      rot.mat <-   procOPA(target.new, this.config, scale = F, reflect = TRUE)$R
      this.theta <- theta.st[i,,]
      theta.st[i,,] <- this.theta%*%rot.mat  # rotate ideal points
    }
    if(estimation$valence==0){
      alpha <- NA
    }
    if(estimation$valence==1){
      alpha <- estimation$posterior[,grep("alpha",colnames(estimation$posterior))]
    }
    return(list(addinfo=estimation$addinfo,deviance=estimation$deviance,
                valence=estimation$valence, distance=estimation$distance, dimension=estimation$dimension,
                group=estimation$group,gener.last=estimation$gener.last,sigma=sigma,
                valence.post=alpha,theta.id=theta.st,v.st=v.st,beta.id=beta.st,targetlist=target_list))
  }
}
