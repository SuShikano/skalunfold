# ---------------------------------------------------------------------------- #
# ##############################################################################
# ##############################################################################
#' This function generates graphics from skalunfold.postestimate(...).
#'
#' @param postestimation Object produced by skalunfold.postestimate(...)
#' @param scalocolors Colors for individual political actors if type="ideology" or
#'        for respondents groups if type="theta" and postestimation argument
#'        does contain a group. Default is NULL.
#' @param type Specifies the type of graphics. "ideology" or "valence" is possible.
#' @param skalo.names Labels of individuals political actors if type="ideology" or
#'        for respondent groups if type="theta".
#' @param plot.density A vector of values specifying the densities to be plotted.
#' @param title A title for the plot
#' @param cex cex-factor for the legend
#' @param cex cex-factor for the points
#' @return Graphic.
# ---------------------------------------------------------------------------- #
# ##############################################################################
# ---------------------------------------------------------------------------- #
# SKALUNFOLD GRAPHS --------------------------------------------------------- #
# ---------------------------------------------------------------------------- #
# ##############################################################################
skalunfold.graph <- function(postestimation, scalocolors=NULL,type="ideology",
                              skalo.names=NULL,plot.density=0.01,title=NULL,
                              legend.cex=1,cex=1){
  if(type=="ideology"){
  if(postestimation$dimension==1){ # ----------------------------------------- #
    if(is.null(title)){
      title="Estimated Ideological Position"
    }
    if(is.null(scalocolors)){
      scalocolors <- rainbow(dim(postestimation$beta.id)[2])
    }

    plot(density(postestimation$beta.id),type="n",main=title,xlab="Ideological Dimension",
         ylim=c(0,max(apply(postestimation$beta.id,2,function(x) max(density(x)$y,na.rm=T)))*1.2),
         xlim=c(min(postestimation$beta.id)*1.1,max(postestimation$beta.id)*1.8))
    for(i in 1:dim(postestimation$beta.id)[2]){
      lines(density(postestimation$beta.id[,i]), col=scalocolors[i])
    }
    if (is.null(skalo.names)) {
       this.label <- as.character(1:ncol(postestimation$beta.id))
    } else {
       this.label <- skalo.names
    }
    legend("bottomright",col=scalocolors,lty=1,lwd=2,
           legend=this.label,cex=legend.cex,bg="white")
  }

  if(postestimation$dimension==2){ # ----------------------------------------- #

    if(is.null(scalocolors)){
      scalocolors <- rainbow(dim(postestimation$beta.id)[2])
    }

    plot(0,type="n",xlim=1.5*c(floor(range(postestimation$beta.id[,,1])[1]),ceiling(range(postestimation$beta.id[,,1])[2])),
         main=title,
         ylim=1.5*c(floor(range(postestimation$beta.id[,,2])[1]),
                    ceiling(range(postestimation$beta.id[,,2])[2])),
         xlab="Dim 1",ylab="Dim 2")

    selected.iter <- sample(1:(nrow(postestimation$beta.id)),300,replace=TRUE)
    for (i in 1:(ncol(postestimation$beta.id))){
      par(new=T)
      f1 <- kde2d(postestimation$beta.id[selected.iter,i,1],
                  postestimation$beta.id[selected.iter,i,2],h = rep(.006, 2))
      #pp <- array()

      #for (j in selected.iter){
      #  print(j)
      #  z.x <- max(which(f1$x < postestimation$beta.id[,i,1][j]))
      #  z.y <- max(which(f1$y < postestimation$beta.id[,i,2][j]))
      #  pp[j] <- f1$z[z.x, z.y]
      #}
      #confidencebound <- quantile(pp, 0.005, na.rm = TRUE)
      #contour(f1, levels  =  confidencebound ,labels=rep("",times=dim(postestimation$beta.id)[2]),add=T,col=scalocolors[i],lwd=2.5)
      contour(f1, levels  =  plot.density ,labels=rep("",times=dim(postestimation$beta.id)[2]),add=T,col=scalocolors[i],lwd=2.5)
    }
    if (is.null(skalo.names)) {
       this.label <- as.character(1:ncol(postestimation$beta.id))
    } else {
       this.label <- skalo.names
    }
    legend("bottomright",col=scalocolors,lty=1,lwd=2,
           this.label,cex=legend.cex,bg="white")
  }

  if(postestimation$dimension==3){ # ----------------------------------------- #

    require(rgl)

    if (is.null(scalocolors)) {
      scalocolors <- rainbow(dim(postestimation$beta.id)[2])
    }

    plot3d(0,0,0,xlab="Dim 1",ylab="Dim 2",zlab="Dim 3",
           xlim=c(floor(range(postestimation$beta.id[,,1])[1]),ceiling(range(postestimation$beta.id[,,1])[2])),
           ylim=c(floor(range(postestimation$beta.id[,,2])[1]),ceiling(range(postestimation$beta.id[,,2])[2])),
           zlim=c(floor(range(postestimation$beta.id[,,3])[1]),ceiling(range(postestimation$beta.id[,,3])[2])))
    for(i in 1:dim(postestimation$beta.id)[2]){
      plot3d(postestimation$beta.id[,i,1],postestimation$beta.id[,i,2],postestimation$beta.id[,i,3], add=T, col=scalocolors[i])
    }
    print("Please see RGL device for output.")
  }
  }

  if(type=="valence"){# ----------------------------------------- #
    if(is.null(title)){
      title="Estimated Valence"
    }
    if(postestimation$valence==0){
      stop("Model fitte without valence. No graph can be produced.")
    }
    if(postestimation$valence==1){
      stop("Model fitte only one single valence for all actors. No graph is needed.")
    }
    if(postestimation$valence==2){# ----------------------------------------- #
   plot(range(postestimation$valence.post),
         c(1,ncol(postestimation$valence.post)),
         ylim=c(1,ncol(postestimation$valence.post)),
         xlim=range(postestimation$valence.post),
         type="n",main=title,xlab="Valence",ylab="", yaxt="n")
    grid(ny=NA,col="DarkGrey",lty=2)
   for(v in 1:ncol(postestimation$valence.post)){
    points(quantile(postestimation$valence.post[,v],c(.025,.975)),
           rep(ncol(postestimation$valence.post)+1-v,2),lty=1,lwd=2,type="l",
           col="Black")
     }

    if (is.null(skalo.names)) {
         this.label <- c(ncol(postestimation$valence.post):1)}
    else {
         this.label <- rev(skalo.names)
         }
    axis(side=2,at=1:ncol(postestimation$valence.post),
         labels=this.label,las=1)
   }

    if(postestimation$valence==3){# ----------------------------------------- #
      plot(range(postestimation$valence.post),
           c(1,ncol(postestimation$valence.post)),
           ylim=c(1,ncol(postestimation$valence.post)),
           xlim=range(postestimation$valence.post),
           type="n",main=title,xlab="Valence",ylab="", yaxt="n")
      grid(ny=NA,col="DarkGrey",lty=2)

      for(g in sort(unique(postestimation$group))){
        valence.temp <-
          postestimation$valence.post[,grep(paste0(",",g),
                                           colnames(postestimation$valence.post))]
      for(v in 1:ncol(valence.temp)){
        points(quantile(valence.temp[,v],c(.025,.975)),
               rep(ncol(postestimation$valence.post)+1-(g-1)*ncol(valence.temp)-v,2),
               lty=1,lwd=2,type="l",
               col="Black")
      }
        abline(h=ncol(postestimation$valence.post)+.5-(g)*ncol(valence.temp),
               lty=1,lwd=1,col="black")
      }
      if (is.null(skalo.names)) {
         this.label <- rep(ncol(postestimation$beta.id):1,
                             length(unique(postestimation$group)))
                             }
      else {
         this.label <- rep(rev(skalo.names),
                             length(unique(postestimation$group)))
         }
      axis(side=2,at=1:ncol(postestimation$valence.post),
                              labels=this.label,las=1)
    }
    if(postestimation$valence==4){# ----------------------------------------- #
      plot(range(postestimation$valence.post),
           c(1,ncol(postestimation$valence.post)),
           ylim=c(1,ncol(postestimation$valence.post)),
           xlim=range(postestimation$valence.post),
           type="n",main=title,xlab="Valence",ylab="", yaxt="n")
      grid(ny=NA,col="DarkGrey",lty=2)
      for(v in 1:postestimation$gener.last){
        points(quantile(postestimation$valence.post[,v],c(.025,.975)),
               rep(ncol(postestimation$valence.post)+1-v,2),lty=1,lwd=2,type="l",
               col="Black")
      }
      abline(h=ncol(postestimation$valence.post)+.5-postestimation$gener.last,
             lty=1,lwd=1,col="black")
      for(g in sort(unique(postestimation$group))){
        valence.temp <-
          postestimation$valence.post[,grep(paste0(",",g),
                                           colnames(postestimation$valence.post))]

        for(v in 1:ncol(valence.temp)){
          points(quantile(valence.temp[,v],c(.025,.975)),
                 rep(ncol(postestimation$valence.post)+1-postestimation$gener.last-(g-1)*ncol(valence.temp)-v,2),
                 lty=1,lwd=2,type="l",
                 col="Black")
        }
        abline(h=ncol(postestimation$valence.post)+.5-postestimation$gener.last-(g)*ncol(valence.temp),
               lty=1,lwd=1,col="black")
      }
      if (is.null(skalo.names)) {
         this.label <- c(rep(ncol(postestimation$beta.id):(postestimation$gener.last+1),
                             length(unique(postestimation$group))),
                         postestimation$gener.last:1)
                             }
      else {
         this.label <- c(rep(rev(skalo.names[(postestimation$gener.last+1):length(skalo.names)]),
                             length(unique(postestimation$group))),
                         rev(skalo.names[1:postestimation$gener.last]))
         }
      axis(side=2,at=1:ncol(postestimation$valence.post),
                                                       labels=this.label,las=1)
  }
  }
  if(type=="theta"){

    if(is.null(title)){title="Estimated Respondent Position"}
    if(is.null(postestimation$group)){
      scalocolors <- rep("Black",ncol(postestimation$v.st))}
    if(!is.null(postestimation$group)){
      if(is.null(scalocolors)){
        scalocolors <- rainbow(length(unique(postestimation$group)))
      }
    }
    makeTransparent<-function(someColor, alpha=80)
    {
      newColor<-col2rgb(someColor)
      apply(newColor, 2, function(curcoldata){rgb(red=curcoldata[1], green=curcoldata[2],
                                                  blue=curcoldata[3],alpha=alpha, maxColorValue=255)})
    }
    scalocolors <- makeTransparent(scalocolors)


    if(postestimation$dimension==1){
      posmat <- apply(postestimation$theta.id,2,mean)
      if(is.null(postestimation$group)){
        plot(density(posmat),
                     main=title,
             xlab="Ideological Dimension",
             ylab="Density")
      }
      if(!is.null(postestimation$group)){
        this.label <- skalo.names

    plot(density(posmat),type="n",main=title,xlab="Ideological Dimension",
         ylim=c(0,max(tapply(posmat,postestimation$group,function(x) max(density(x)$y,na.rm=T)))*1.2),
         xlim=c(min(posmat)*1.1,max(posmat)*1.8))
        u.groups <- sort(unique(postestimation$group))
        for(i in u.groups){
        dens <- density(posmat[postestimation$group==i])
        lines(dens,
              col=scalocolors[i],
              lwd=1.5)
      x1 <- which(dens$x ==min(dens$x))
      x2 <- which(dens$x ==max(dens$x))
      with(dens, polygon(x=c(x[c(x1,x1:x2,x2)]),
                         y= c(0, y[x1:x2], 0),
                         col=scalocolors[i],
                         border=scalocolors[i]))
        }
        if(is.null(this.label)){
        this.label <- u.groups
        }
        legend("topright",col=scalocolors,
               lty=1,lwd=2,
               legend=this.label,
               cex=legend.cex,bg="white")

       }

    }

    if(postestimation$dimension==2){

    posmat <- apply(postestimation$theta.id,c(2,3),mean)

    if(is.null(postestimation$group)){
      plot(posmat[,1],posmat[,2],
           pch=19,
           col=makeTransparent("Black"),
           main=title,
           xlab="First Dimension",
           ylab="Second Dimension")
    }
    if(!is.null(postestimation$group)){
      u.groups <- sort(unique(postestimation$group))
      this.color <- scalocolors[u.groups]
      this.label <- skalo.names
      if(is.null(this.label)){
        this.label <- u.groups

      }
    scalocolors <- scalocolors[postestimation$group]

    plot(posmat[,1],posmat[,2],
        pch=19,
        col=scalocolors,
        main=title,
        xlab="First Dimension",
        ylab="Second Dimension",
        xlim=c(min(posmat[,1]),1.5*max(posmat[,1])),
        ylim=range(posmat))

    legend("topright",col=this.color,
           pch=19,
           legend=this.label,
           cex=legend.cex,bg="white")
    }

    }
  if(postestimation$dimension==3){
    print("Type 'Theta' not implemented for more than two dimensions")
  }
  }

}
